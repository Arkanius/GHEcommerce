<?php
App::uses('ProdutosController', 'Controller');

/**
 * ProdutosController Test Case
 *
 */
class ProdutosControllerTest extends ControllerTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.produto',
		'app.usuario',
		'app.comentario',
		'app.foto',
		'app.categoria',
		'app.categorias_produto',
		'app.compra',
		'app.notificacao',
		'app.compras_produto'
	);

/**
 * testIndex method
 *
 * @return void
 */
	public function testIndex() {
	}

/**
 * testView method
 *
 * @return void
 */
	public function testView() {
	}

/**
 * testAdd method
 *
 * @return void
 */
	public function testAdd() {
	}

/**
 * testEdit method
 *
 * @return void
 */
	public function testEdit() {
	}

/**
 * testDelete method
 *
 * @return void
 */
	public function testDelete() {
	}

}
